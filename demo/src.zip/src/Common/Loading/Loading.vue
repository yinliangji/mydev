<template>
    <div class="loading">
        loading...
    </div>
</template>
