<template>
	<div class="pageContent">
		<Breadcrumb :style="{margin: '16px 0'}">
            <BreadcrumbItem>首页</BreadcrumbItem>
            <BreadcrumbItem>工作台</BreadcrumbItem>
            <BreadcrumbItem>我的任务</BreadcrumbItem>
        </Breadcrumb>
		page2
	</div>
</template>
<script>
export default {

}
</script>
<style lang="less" scoped>
@import './style.less';
@import './style.css';

</style>