export const CODE_200 = '成功'
export const CODE_404 = '系统错误'
export const CODE_500 = '失败'
