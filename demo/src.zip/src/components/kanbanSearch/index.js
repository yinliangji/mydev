import kanbanSearch from './kanban-search';

export default kanbanSearch;