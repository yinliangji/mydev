import myselectMenu1 from './selectMenu1.vue'

const selectMenu1 = {
    install: function(Vue) {
        Vue.component('selectMenu1', myselectMenu1)
    }
};
export default selectMenu1;