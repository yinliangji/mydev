import kanbanBoard from './kanbanBoard';

export default kanbanBoard;