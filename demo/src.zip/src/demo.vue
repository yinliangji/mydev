<template>
	<Sider  collapsible :collapsed-width="78" :style="{background:'red',height:'100%'}"   hide-trigger></Sider>
</template>
<script>
	export default {

	}
</script>
<style lang="less" scoped>

</style>